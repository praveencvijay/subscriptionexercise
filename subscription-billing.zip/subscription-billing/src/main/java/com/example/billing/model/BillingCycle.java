package com.example.billing.model;

public enum BillingCycle {

    MONTHLY(1),
    QUARETERLY(3);

    private final int duration;

    BillingCycle(int duration) {
        this.duration = duration;
    }

    public int getDuration() {
        return duration;
    }

}
