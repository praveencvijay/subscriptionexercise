package com.example.billing.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.billing.entity.Customer;
import com.example.billing.model.Plan;
import com.example.billing.model.Usage;
import com.example.billing.repository.CustomerRepository;
import com.example.billing.service.BillingService;

@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
    private CustomerRepository customerRepo;

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        Customer saved = customerRepo.save(customer);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getCustomer(@PathVariable("id") Long id) {
        Optional<Customer> customerOpt = customerRepo.findById(id);
        if (customerOpt.isPresent()) {
            return ResponseEntity.ok(customerOpt.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable("id") Long id, @RequestBody Customer updated) {
        Optional<Customer> customerOpt = customerRepo.findById(id);
        if (customerOpt.isPresent()) {
            Customer customer = customerOpt.get();
            customer.setName(updated.getName());
            customer.setEmail(updated.getEmail());
            customer.setSubscriptionType(updated.getSubscriptionType());
            customer.setStartDate(updated.getStartDate());
            customer.setBillingCycle(updated.getBillingCycle());
            Customer saved = customerRepo.save(customer);
            return ResponseEntity.ok(saved);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    @PatchMapping("/{id}/usage")
    public ResponseEntity<Customer> updateCustomer(@PathVariable("id") Long id, @RequestBody Usage usage) {
        Optional<Customer> customerOpt = customerRepo.findById(id);
        if (customerOpt.isPresent()) {
            Customer customer = customerOpt.get();
            customer.setActiveUsage((customer.getActiveUsage()== null? 0 : customer.getActiveUsage()) + usage.getRequestCount());
            Customer saved = customerRepo.save(customer);
            return ResponseEntity.ok(saved);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
}