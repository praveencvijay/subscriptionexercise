package com.example.billing.model;

public class Usage {

	private int requestCount;

	public int getRequestCount() {
		return requestCount;
	}

	public void setRequestCount(int requestCount) {
		this.requestCount = requestCount;
	}
	
}
