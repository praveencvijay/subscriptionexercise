package com.example.billing.model;

import com.example.billing.strategy.BillingStrategy;

public class Subscription {
    private SubscriptionType subscriptionType;
    private BillingCycle billingCycle;
    private int usage;
    private BillingStrategy billingStrategy;

    public Subscription(SubscriptionType subscriptionType, BillingCycle billingCycle, BillingStrategy billingStrategy) {
        this.subscriptionType = subscriptionType;
        this.billingCycle = billingCycle;
        this.billingStrategy = billingStrategy;
    }

    public double generateBill() {
        return billingStrategy.generateBill(this);
    }

	public int getUsage() {
		return usage;
	}

	public void setUsage(int usage) {
		this.usage = usage;
	}

	public BillingStrategy getBillingStrategy() {
		return billingStrategy;
	}

	public void setBillingStrategy(BillingStrategy billingStrategy) {
		this.billingStrategy = billingStrategy;
	}

	public SubscriptionType getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(SubscriptionType subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public BillingCycle getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(BillingCycle billingCycle) {
		this.billingCycle = billingCycle;
	}

    
    
}
