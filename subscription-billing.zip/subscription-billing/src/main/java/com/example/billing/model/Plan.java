package com.example.billing.model;

public class Plan {
	
	private String name;
    private double fixedRate;
    private double ratePerUnit;
    
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getFixedRate() {
		return fixedRate;
	}
	public void setFixedRate(double fixedRate) {
		this.fixedRate = fixedRate;
	}
	public double getRatePerUnit() {
		return ratePerUnit;
	}
	public void setRatePerUnit(double ratePerUnit) {
		this.ratePerUnit = ratePerUnit;
	}


    // Constructors, getters, setters
}
