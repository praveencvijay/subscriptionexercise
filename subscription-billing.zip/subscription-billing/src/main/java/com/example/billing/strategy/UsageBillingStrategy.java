package com.example.billing.strategy;

import com.example.billing.model.Subscription;

public class UsageBillingStrategy implements BillingStrategy {
	
    public double generateBill(Subscription subscription) {
    	int usage = subscription.getUsage();
    	if(usage == 0) {
    		usage = 1;
    	}
        return  usage *
        		subscription.getSubscriptionType().getRate() * subscription.getBillingCycle().getDuration();
    }
}
