package com.example.billing.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.example.billing.entity.Customer;
import com.example.billing.entity.InvoiceHistory;
import com.example.billing.model.BillingCycle;
import com.example.billing.model.Subscription;
import com.example.billing.model.SubscriptionType;
import com.example.billing.repository.CustomerRepository;
import com.example.billing.strategy.BillingStrategy;
import com.example.billing.strategy.FixedBillingStrategy;
import com.example.billing.strategy.UsageBillingStrategy;

import jakarta.transaction.Transactional;

@Service
public class BillingService {

	private Map<String, BillingStrategy> billingStrategies;

	@Autowired
	private CustomerRepository customerRepo;

	public BillingService() {
		billingStrategies = new HashMap<>();
		billingStrategies.put("FIXED", new FixedBillingStrategy());
		billingStrategies.put("USAGE", new UsageBillingStrategy());
	}

	private double generateBillOnTypeAndCycle(SubscriptionType subscriptionType, BillingCycle billingCycle, int usage) {
		BillingStrategy billingStrategy = billingStrategies.get(subscriptionType.name().split("_")[1]);
		Subscription subscription = new Subscription(subscriptionType, billingCycle, billingStrategy);
		subscription.setUsage(usage);
		return subscription.generateBill();

	}

	@Transactional
	@Scheduled(cron = "0 */2 * * * ?")
	public void generateBill() {

		List<Customer> allCustomers = customerRepo.findAll();

		for (Customer customer2 : allCustomers) {

			Optional<InvoiceHistory> latestInvoiceHistory = customer2.getInvoiceHistory().stream()
					.max(Comparator.comparing(InvoiceHistory::getId));
			Date lastInvoiceDate = latestInvoiceHistory.map(InvoiceHistory::getInvoiceDate).orElse(null);
			BillingCycle billingCycle = customer2.getBillingCycle();
			if (BillingCycle.MONTHLY.equals(billingCycle)
					&& isTimeToGenerate(lastInvoiceDate, BillingCycle.MONTHLY.getDuration())
					|| (BillingCycle.QUARETERLY.equals(billingCycle)
							&& isTimeToGenerate(lastInvoiceDate, BillingCycle.QUARETERLY.getDuration()))) {

				double billAmount = generateBillOnTypeAndCycle(customer2.getSubscriptionType(),
						customer2.getBillingCycle(),
						customer2.getActiveUsage() == null ? 0 : customer2.getActiveUsage());

				InvoiceHistory invoiceHistory = new InvoiceHistory();
				invoiceHistory.setBillAmount(billAmount);
				invoiceHistory.setInvoiceDate(Date.valueOf(LocalDate.now()));
				invoiceHistory.setUsage(customer2.getActiveUsage());
				customer2.getInvoiceHistory().add(invoiceHistory);
				customer2.setActiveUsage(0);
				customerRepo.save(customer2);

			}
		}

	}

	private boolean isTimeToGenerate(Date date, int noOfMonths) {
		LocalDate previousDate = date.toLocalDate();
		LocalDate today = LocalDate.now();
		// Option 1: Check if more than noOfMonths month has passed
		return previousDate.isBefore(today.minusMonths(noOfMonths));
	}

	public List<InvoiceHistory> generateBill(Long customerId) {

		Optional<Customer> customerOpt = customerRepo.findById(customerId);
		Customer customer = customerOpt.orElseThrow(() -> new RuntimeException("Customer not found"));

		// get usage from a usage table aganist customer

		double billAmount = generateBillOnTypeAndCycle(customer.getSubscriptionType(), customer.getBillingCycle(),
				customer.getActiveUsage() == null ? 0 : customer.getActiveUsage());

		InvoiceHistory invoiceHistory = new InvoiceHistory();
		invoiceHistory.setBillAmount(billAmount);
		invoiceHistory.setInvoiceDate(Date.valueOf(LocalDate.now()));
		invoiceHistory.setUsage(customer.getActiveUsage());
		customer.getInvoiceHistory().add(invoiceHistory);
		customer.setActiveUsage(0);
		customerRepo.save(customer);
		return customer.getInvoiceHistory();

	}
}
