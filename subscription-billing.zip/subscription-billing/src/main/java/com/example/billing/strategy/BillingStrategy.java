package com.example.billing.strategy;

import com.example.billing.model.Subscription;

public interface BillingStrategy {
	
    double generateBill(Subscription subscription);
}
