package com.example.billing.model;

public enum SubscriptionType {

    BASIC_FIXED(99.0),
    BASIC_USAGE(0.50),
    PRO_FIXED(199.0),
    PRO_USAGE(0.25),
    ENTERPRISE_FIXED(299.0),
    ENTERPRISE_USAGE(0.10);

    private final double rate;

    SubscriptionType(double rate) {
        this.rate = rate;
    }

    public double getRate() {
        return rate;
    }

}
