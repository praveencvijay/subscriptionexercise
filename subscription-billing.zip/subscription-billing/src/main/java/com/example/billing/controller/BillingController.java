package com.example.billing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.billing.entity.InvoiceHistory;
import com.example.billing.model.Resource;
import com.example.billing.service.BillingService;

import jakarta.transaction.Transactional;

@RestController
@RequestMapping("/billing")
public class BillingController {

	@Autowired
	private BillingService billingService;



	@PostMapping
	@Transactional
	public List<InvoiceHistory> generateInvoice(@RequestBody Resource resource) {
		
		return billingService.generateBill(resource.getCustomerId());
	}
	
	
}
