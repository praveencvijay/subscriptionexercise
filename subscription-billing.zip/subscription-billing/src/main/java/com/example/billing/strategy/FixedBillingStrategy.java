package com.example.billing.strategy;

import com.example.billing.model.Subscription;

public class FixedBillingStrategy implements BillingStrategy {
	
	public double generateBill(Subscription subscription) {
		return subscription.getSubscriptionType().getRate() * 
				subscription.getBillingCycle().getDuration();
	}
}
